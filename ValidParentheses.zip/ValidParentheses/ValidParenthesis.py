class Solution(object):
    def isValid(self, s):
        """
        :type s: str
        :rtype: bool
        """
        stack = []

        brackets_map = {")": "(", "}": "{", "]": "["}

        for char in s:
            if char in brackets_map.values():
                stack.append(char)
            else:
                if not stack or stack.pop() != brackets_map[char]:
                    return False

        return len(stack) == 0